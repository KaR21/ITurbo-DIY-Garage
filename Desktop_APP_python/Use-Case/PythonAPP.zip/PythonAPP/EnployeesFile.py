from Person import Person
import Basic_Metods

class Enployees(Person):
    def __init__(self,i, n, s, mp, hp, e, passw, a, c, p, r, cond, ssa):
        super(Enployees, self).__init__(i, n, s, mp, hp, e, passw, a, c, p, r, cond)

        self.Salary = ssa

    def setSalary(self):
            self.Salary = Basic_Metods.BasicMethods.askString("Enter the salary")

    def print(self):
        print(self.Enployee_Id, self.First_name, self.Surname, self.Role, self.Home_Phone, self.Mobile_Phone, self.Email, self.Password, self.Adress, self.City, self.Postcode, self.Condition, self.Salary)
        
