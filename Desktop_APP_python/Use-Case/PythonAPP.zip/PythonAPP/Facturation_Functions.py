from functools import total_ordering
import Basic_Metods

def menuFacturation():
    option = -1
    #print("For the management system of the facturation what file do you want to use?")
    #filename = Basic_Metods.BasicMethods.askForFile()

    while (option !=0):
        print("\n------------------------MENU EMPLOYEES------------------------")
        print("1) See all the facturation")
        print("2) See all the facturation of the bookings")
        print("3) See all the facturation of the products")
        print("0) Exit")
        print("--------------------------------------------------------------\n")
        option = Basic_Metods.BasicMethods.askAnInt("Enter your option: ")
        if option == 1:
            filename = "Facturation.pkl"
            total = saveAllTheFacturation(filename)
            show_all_facturation(filename, total)

        elif option == 2:
            filename = "FacturationBookings.pkl"
            total = saveAllTheBookingsFacturation(filename)
            show_all_the_bookings_facturation(filename, total)

        elif option == 3:
            filename = "FacturationProducts.pkl"
            total = saveAllTheProductsFacturation(filename)
            show_all_the_products_facturation(filename, total)
            
def saveAllTheFacturation(fileName):
    totalAmount = 0
    bookingscabin = Basic_Metods.BasicMethods.readFileToList("Bookcabin.pkl")
    bookingsservices = Basic_Metods.BasicMethods.readFileToList("Bookservice.pkl")
    products = Basic_Metods.BasicMethods.readFileToList("Products.pkl")
    facturation = []
    for st in bookingscabin:
        totalAmount = totalAmount + st.getprice()
        facturation.append(st)
    for sd in bookingsservices:
        totalAmount = totalAmount + sd.getprice()
        facturation.append(sd)
    for sp in products:
        totalAmount = totalAmount + sp.getprice()
        facturation.append(sp)
    Basic_Metods.BasicMethods.writeFile(fileName, facturation)
    
    return totalAmount
    

def show_all_facturation(fileName, totalAmount):
    print("\n---------------------------------------------------------------------")
    print("--------------- You are going to SEE all the facturation.--------------")
    print("---------------------------------------------------------------------\n")
    Basic_Metods.BasicMethods.readFile(fileName)
    print(f"\nTotal amount: %f", totalAmount)


def saveAllTheBookingsFacturation(fileName):
    bookings = Basic_Metods.BasicMethods.readFileToList(fileName)
    totalAmount = 0
    facturation = []
    for st in bookings:
        totalAmount = totalAmount + st.getPrice()
        facturation.append(st)
    Basic_Metods.BasicMethods.writeFile(fileName, facturation)
    return totalAmount

def show_all_the_bookings_facturation(fileName, totalAmount):
    print("\n---------------------------------------------------------------------")
    print("----------- You are going to SEE bookings the facturation.-------------")
    print("---------------------------------------------------------------------\n")
    Basic_Metods.BasicMethods.readFile(fileName)
    print("\nTotal amount: " + str(totalAmount))

def saveAllTheProductsFacturation(fileName):
    products = Basic_Metods.BasicMethods.readFileToList(fileName)
    totalAmount = 0
    facturation = []
    for st in products :
        totalAmount = totalAmount + st.getPrice()
        facturation.append(st)
    Basic_Metods.BasicMethods.writeFile(fileName, facturation)
    return totalAmount

def show_all_the_products_facturation(filename, total):
    print("\n---------------------------------------------------------------------")
    print("----------- You are going to SEE products the facturation.-------------")
    print("---------------------------------------------------------------------\n")
    Basic_Metods.BasicMethods.readFile(filename)
    print("\nTotal amount: " + str(total))