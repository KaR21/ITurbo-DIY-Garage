import Basic_Metods

class BookingCabin:
    def __init__(self, id,d,hourIn,hourOut,cusID, c, a, p): #Constructor

        self.id = id
        self.date = d
        self.hourIn = hourIn
        self.hourOut = hourOut
        self.cusID = cusID
        self.cabinID = c
        self.available = a
        self.price = p
        
    def setid(self):
        self.id = Basic_Metods.BasicMethods.askAString("Enter the new id:\n")

    def setdate(self):
        self.date = Basic_Metods.BasicMethods.askAString("Enter the new date:\n")
    
    def sethourIn(self):
        self.hourIn = Basic_Metods.BasicMethods.askAString("Enter the new hourIn:\n")
    
    def sethourOut(self):
        self.hourOut = Basic_Metods.BasicMethods.askAString("Enter the new hourOut:\n")

    def setcusID(self):
        self.cusID = Basic_Metods.BasicMethods.askAString("Enter the new cusID:\n")
    
    def setcabinID(self):
        self.cabinID = Basic_Metods.BasicMethods.askAnInt("Enter the new cabinID:\n")
        
    def setavailable(self):
        self.available = Basic_Metods.BasicMethods.askAString("Enter the new available:\n")
    
    def setprice(self):
        self.price = Basic_Metods.BasicMethods.askAnDouble("Enter the new price:\n")


    def getid(self):
        return self.dni

    def getdate(self):
        return self.date

    def gethourIn(self):
        return self.hourIn

    def gethourOut(self):
        return self.hourOut
    
    def getcusID(self):
        return self.cusID

    def getcabinID(self):
        return self.cabinID
    
    def getavailable(self):
        return self.available

    def getprice(self):
        return self.price


    def toString(self):
        print(self.id, self.date, self.hourIn, self.hourOut, self.cusID, self.cabinID, self.available, self.price)
        